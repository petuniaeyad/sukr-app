import 'package:get/get.dart';
import 'package:sukar/presintation/controller/chat_pot_controller.dart';

class ChatPotBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ChatPotController>(() => ChatPotController());
  }
}
