import 'package:get/get.dart';
import 'package:sukar/presintation/controller/story_controller.dart';

class StoryBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<StoriesController>(() => StoriesController());
  }
}
