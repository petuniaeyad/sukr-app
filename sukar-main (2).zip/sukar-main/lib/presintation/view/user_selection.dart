import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sukar/utils/app_general.dart';
import 'package:sukar/utils/constant.dart';
import 'package:sukar/utils/routes/routes_string.dart';

class UserTypeSelectionScreen extends StatelessWidget {
  const UserTypeSelectionScreen({super.key});

  // تعديل قائمة أنواع المستخدمين حسب احتياجك
  final List<_UserType> userTypes = const [
    _UserType(id: 'child', label: 'طفل', icon: Icons.child_care),
    _UserType(id: 'parents', label: 'ولي الأمر', icon: Icons.family_restroom),
    _UserType(id: 'caregiver', label: 'مرافق', icon: Icons.health_and_safety),
  ];

  @override
  Widget build(BuildContext context) {
    final Color primary = const Color(0xFF5a5ea3);
    final double w = width(context);
    return Scaffold(
      backgroundColor: const Color(0xffe7f0f1),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
          child: Column(
            children: [
              // عنوان وشعار
              Text(
                'Sukr',
                style: TextStyle(
                  fontFamily: 'PoetsenOne',
                  fontSize: w * 0.14,
                  color: primary,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              Text(
                'اختر نوع المستخدم',
                style: TextStyle(
                  fontFamily: 'PoetsenOne',
                  fontSize: 22,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 32),
              // شبكة البطاقات
              Expanded(
                child: GridView.builder(
                  itemCount: userTypes.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 16,
                    crossAxisSpacing: 16,
                    childAspectRatio: 1,
                  ),
                  itemBuilder: (_, idx) {
                    final type = userTypes[idx];
                    return Material(
                      color: Colors.white,
                      elevation: 4,
                      borderRadius: BorderRadius.circular(16),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(16),
                        onTap: () {
                          // حفظ النوع للاستخدام لاحقاً
                          AppGeneral.calsification = type.id;
                          Get.toNamed(RoutesString.login);
                        },
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(type.icon, size: 48, color: primary),
                            const SizedBox(height: 12),
                            Text(
                              type.label,
                              style: TextStyle(
                                fontFamily: 'PoetsenOne',
                                fontSize: 18,
                                fontWeight: FontWeight.w600,
                                color: primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UserType {
  final String id;
  final String label;
  final IconData icon;
  const _UserType({required this.id, required this.label, required this.icon});
}
