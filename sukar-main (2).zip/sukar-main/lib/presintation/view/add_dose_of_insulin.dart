import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sukar/presintation/controller/parents_controller.dart';
import 'package:sukar/presintation/widgets/text_field.dart';
import 'package:sukar/utils/tools.dart';

class AddDoseOfInsulin extends StatelessWidget {
  const AddDoseOfInsulin({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: ParentsController(),
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: Text("Manage Your insuline".tr),
            backgroundColor: const Color(0xFF5a5ea3),
          ),
          body: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Medication Name".tr,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  MainTextField(
                    controller: controller.nameController,
                    hint: "Insuline".tr,
                    textInputType: TextInputType.text,
                    isBorder: true,

                    enabled: true,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Dose (e.g. 500mg)".tr,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  MainTextField(
                    controller: controller.insulineDose,
                    hint: "Enter dose".tr,
                    textInputType: TextInputType.text,
                    isBorder: true,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Time to Take".tr,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  GestureDetector(
                    onTap: controller.pickMealTime,
                    child: AbsorbPointer(
                      child: MainTextField(
                        controller: controller.insulineTime,
                        hint: "Tap to pick time".tr,
                        textInputType: TextInputType.text,
                        isBorder: true,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  Center(
                    child: ElevatedButton(
                      onPressed: () {
                        appTools.showAlertDialogTwoFun(
                          Get.context!,
                          content:
                              "Do you need To Add A Notification Remember".tr,
                          title: "Notification Remmebr".tr,
                          yes: () {
                            controller.nameController.clear();
                            controller.insulineDose.clear();
                            controller.insulineTime.clear();
                            Get.back();
                            Get.snackbar(
                              'added'.tr,
                              'You Added midication With Remmber'.tr,
                            );
                          },
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF5a5ea3),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: Text("Add Dose".tr),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
