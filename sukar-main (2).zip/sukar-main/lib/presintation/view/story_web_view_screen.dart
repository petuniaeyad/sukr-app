import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class StoryWebViewPage extends StatefulWidget {
  final String url;
  final String title;

  const StoryWebViewPage({super.key, required this.url, required this.title});

  @override
  State<StoryWebViewPage> createState() => StoryWebViewPageState();
}

class StoryWebViewPageState extends State<StoryWebViewPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: WebViewWidget(controller: _controller),
    );
  }
}
