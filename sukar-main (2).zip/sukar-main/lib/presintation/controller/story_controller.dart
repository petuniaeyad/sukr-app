

import 'package:get/get.dart';
import 'package:sukar/model/story_model.dart';

class StoriesController extends GetxController {
  var stories =
      <StoryModel>[
        StoryModel(
          title: "الأخوة الأربعة وكومة العظام",
          imageUrl:
              "https://www.hikayatatfal.com/wp-content/uploads/2022/06/الأخوة-الأربعة-وكومة-العظام-1.png",
          url:
              "https://www.hikayatatfal.com/إخوة-وكومة-العظام-قصص-أطفال-قصيرة/",
        ),
        StoryModel(
          title: "الفتاة الشجاعة – لا تخاف أبداً",
          imageUrl:
              "https://www.hikayatatfal.com/wp-content/uploads/2022/06/قصة-الفتاة-الشجاعة-حكايات-للأطفال.png",
          url: "https://www.hikayatatfal.com/قصة-الفتاة-الشجاعة/",
        ),
        StoryModel(
          title: "قصة حب الأم والمرآة السحرية",
          imageUrl:
              "https://www.hikayatatfal.com/wp-content/uploads/2022/06/قصة-المرآة-السحرية-قصة-عن-الأم.png",
          url: "https://www.hikayatatfal.com/قصة-المرآة-السحرية-قصة-عن-الأم/",
        ),
      ].obs;
}
