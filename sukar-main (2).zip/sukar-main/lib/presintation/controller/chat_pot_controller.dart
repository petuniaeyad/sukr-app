import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ChatPotController extends GetxController {
  final String apiKey =
      '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';

  final TextEditingController chatPotController = TextEditingController();
  final RxList<Map<String, String>> chatPotMessages =
      <Map<String, String>>[].obs;
  final RxBool isLoading = false.obs;
  Future<String> sendChatPotMessageApi(String message) async {
    const String apiUrl = 'https://api.openai.com/v1/chat/completions';

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        "model": "gpt-4.1-2025-04-14",
        "messages": [
          {
            "role": "system",
            "content":
                "أنت مساعد صحي للأطفال المصابين بالسكري، أجب بطريقة ودودة ومبسطة.",
          },
          {"role": "user", "content": message},
        ],
        "temperature": 0.7,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final reply = data['choices'][0]['message']['content'];
      return reply.trim();
    } else {
      return "حدث خطأ أثناء الاتصال بالخدمة.";
    }
  }

  void chatPotsendMessage() async {
    if (chatPotController.text.isEmpty) return;

    chatPotMessages.add({"role": "user", "text": chatPotController.text});
    chatPotController.clear();

    final reply = await sendChatPotMessageApi(chatPotController.text);

    chatPotMessages.add({"role": "bot", "text": reply});
  }
}
