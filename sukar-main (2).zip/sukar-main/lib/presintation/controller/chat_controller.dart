import 'dart:convert';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:http/http.dart' as http;
import 'package:sukar/model/chat_model.dart';
import 'package:sukar/model/child_profile_model.dart';
import 'package:sukar/utils/app_general.dart';

class ChatController extends GetxController {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final RxList<ChatMessage> messages = <ChatMessage>[].obs;
  final RxString messageText = ''.obs;

  String currentUserId = FirebaseAuth.instance.currentUser!.uid;
  String chatWithUserId = '${AppGeneral.childProfileModel?.parentId}';
  String parentName = '';

  final TextEditingController textController = TextEditingController();

  
  final RxBool isLoading = false.obs;

  @override
  void onInit() async {
    super.onInit();
    await getchild();
    await getparentName();
    _listenToMessages();
  }

  void _listenToMessages() {
    firestore
        .collection('chats')
        .doc(
          '$currentUserId'
          '_'
          '$chatWithUserId',
        )
        .collection('messages')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .listen((snapshot) {
          messages.value =
              snapshot.docs
                  .map((doc) => ChatMessage.fromMap(doc.data(), doc.id))
                  .toList();
        });
  }

  Future<void> getchild() async {
    await firestore
        .collection('caregivers')
        .doc(currentUserId)
        .collection('children')
        .get()
        .then((querySnapshot) {
          for (var doc in querySnapshot.docs) {
            final data = doc.data();
            AppGeneral.childProfileModel = ChildProfileModel.fromJson(data);

            log(AppGeneral.childProfileModel!.parentId.toString());
          }
        })
        .catchError((e) {
          debugPrint('خطأ في جلب الأطفال: $e');
        });
  }

  Future<String> getparentName() async {
    AppGeneral.snapshot =
        await firestore.collection('users').doc(chatWithUserId).get();

    parentName =
        '${AppGeneral.snapshot!['firstName']} ${AppGeneral.snapshot!['lastName']}';
    log(parentName);
    return parentName;
  }

  void sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    final message = ChatMessage(
      id: '',
      senderId: currentUserId,
      receiverId: chatWithUserId,
      message: text,
      timestamp: DateTime.now(),
    );

    await firestore
        .collection('chats')
        .doc(chatId())
        .collection('messages')
        .add(message.toMap());

    messageText.value = '';
    await FirebaseFirestore.instance.collection('chats').doc(chatId()).set({
      'users': chatId(),
      'lastMessage': text,
      'lastTimestamp': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  String chatId() {
    return currentUserId.hashCode <= chatWithUserId.hashCode
        ? '${currentUserId}_$chatWithUserId'
        : '${chatWithUserId}_$currentUserId';
  }


  
}
