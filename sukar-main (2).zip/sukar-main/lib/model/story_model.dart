class StoryModel {
  final String title;
  final String imageUrl;
  final String url;

  StoryModel({required this.title, required this.imageUrl, required this.url});
}
